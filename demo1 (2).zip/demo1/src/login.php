<?php
session_start();
require_once __DIR__ . '/helpers.php';

$login = trim($_POST['login'] ?? '');
$password = trim($_POST['password'] ?? '');

if ($login === '' || $password === '') {
    echo 'Введите логин и пароль!';
    exit;
}

$connect = getDB();

// Проверка пользователя
$stmt = $connect->prepare("SELECT id FROM users WHERE login = ? AND password = ?");
$stmt->bind_param("ss", $login, $password);
$stmt->execute();
$result = $stmt->get_result();

if ($user = $result->fetch_assoc()) {
    $_SESSION['user']['id'] = $user['id'];
    header("Location: http://localhost/demo1/profile.php");
    exit;
}
$stmt->close();

// Проверка администратора
$stmt = $connect->prepare("SELECT id FROM admin WHERE login = ? AND password = ?");
$stmt->bind_param("ss", $login, $password);
$stmt->execute();
$result = $stmt->get_result();

if ($admin = $result->fetch_assoc()) {
    $_SESSION['admin_logged_in'] = true;
    $_SESSION['admin_id'] = $admin['id'];
    header("Location: http://localhost/demo1/admin_panel.php");
    exit;
}
$stmt->close();

// Если не нашли ни пользователя, ни администратора
echo "<script>alert('Вы ввели некорректные данные!');</script>";
?>
