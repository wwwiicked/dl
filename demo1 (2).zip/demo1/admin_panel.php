<?php
session_start();
require_once __DIR__ . '/src/helpers.php';

// Проверяем авторизацию администратора
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.html');
    exit;
}

$connect = getDB();

// Обработка обновления статуса заявки
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && $_POST['action'] === 'update_status') {
        $app_id = intval($_POST['app_id'] ?? 0);
        $status = $_POST['status'] ?? '';

        $allowed_statuses = ['Новая', 'В работе', 'Отменена'];
        if ($app_id > 0 && in_array($status, $allowed_statuses)) {
            $stmt = $connect->prepare("UPDATE applications SET status = ? WHERE id = ?");
            $stmt->bind_param("si", $status, $app_id);
            $stmt->execute();
            $stmt->close();
        }
    }
    elseif (isset($_POST['action']) && $_POST['action'] === 'delete') {
        $app_id = intval($_POST['app_id'] ?? 0);
        if ($app_id > 0) {
            // Удаляем заявку
            $stmt = $connect->prepare("DELETE FROM applications WHERE id = ?");
            $stmt->bind_param("i", $app_id);
            $stmt->execute();
            $stmt->close();
        }
    }

    // Чтобы избежать повторной отправки формы
    header("Location: ".$_SERVER['PHP_SELF']);
    exit;
}

// Получаем заявки со статусом "Новая" и выше (можно изменить фильтр)
$stmt = $connect->prepare("SELECT a.id, a.transport_date, a.weight, a.dimensions, a.address_from, a.address_to, a.cargo_type, a.status, a.created_at, u.name, u.surname FROM applications a JOIN users u ON a.user_id = u.id WHERE a.status IN ('Новая', 'В работе', 'Отменена') ORDER BY a.created_at DESC");
$stmt->execute();
$result = $stmt->get_result();

$applications = [];
while ($row = $result->fetch_assoc()) {
    $applications[] = $row;
}
$stmt->close();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8" />
    <title>Панель администратора</title>
    <link rel="stylesheet" href="assets/style2.css" />
    <style>
        table {
            width: 100%; border-collapse: collapse; margin-top: 20px;
        }
        th, td {
            border: 1px solid #ccc; padding: 8px; text-align: left;
        }
        select, button {
            padding: 5px;
        }
        form {
            margin: 0;
        }
    </style>
</head>
<body>
<div class="container">
    <aside class="sidebar">
        <div class="logo">
            <h1>Панель администратора</h1>
        </div>
        <nav>
            <a href="src/logout.php" class="logout">&larr; Выйти</a>
        </nav>
    </aside>

    <main class="main-content">
        <h2>Заявки пользователей</h2>
        <?php if (empty($applications)): ?>
            <p>Заявок нет.</p>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>Пользователь</th>
                        <th>Дата перевозки</th>
                        <th>Вес (кг)</th>
                        <th>Габариты</th>
                        <th>Откуда</th>
                        <th>Куда</th>
                        <th>Тип груза</th>
                        <th>Статус</th>
                        <th>Действия</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($applications as $app): ?>
                        <tr>
                            <td><?= htmlspecialchars($app['name'] . ' ' . $app['surname']) ?></td>
                            <td><?= htmlspecialchars($app['transport_date']) ?></td>
                            <td><?= htmlspecialchars($app['weight']) ?></td>
                            <td><?= htmlspecialchars($app['dimensions']) ?></td>
                            <td><?= htmlspecialchars($app['address_from']) ?></td>
                            <td><?= htmlspecialchars($app['address_to']) ?></td>
                            <td><?= htmlspecialchars($app['cargo_type']) ?></td>
                            <td>
                                <form method="POST" style="display:inline-block;">
                                    <input type="hidden" name="app_id" value="<?= $app['id'] ?>" />
                                    <input type="hidden" name="action" value="update_status" />
                                    <select name="status" onchange="this.form.submit()">
                                        <option value="Новая" <?= $app['status'] === 'Новая' ? 'selected' : '' ?>>Новая</option>
                                        <option value="В работе" <?= $app['status'] === 'В работе' ? 'selected' : '' ?>>В работе</option>
                                        <option value="Отменена" <?= $app['status'] === 'Отменена' ? 'selected' : '' ?>>Отменена</option>
                                    </select>
                                </form>
                            </td>
                            <td>
                                <form method="POST" onsubmit="return confirm('Удалить заявку?');" style="display:inline-block;">
                                    <input type="hidden" name="app_id" value="<?= $app['id'] ?>" />
                                    <input type="hidden" name="action" value="delete" />
                                    <button type="submit" style="color: red;">Удалить</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </main>
</div>
</body>
</html>
