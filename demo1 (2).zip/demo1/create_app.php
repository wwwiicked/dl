<?php
session_start();
require_once __DIR__ . '/src/helpers.php'; // Подключение к базе данных

$connect = getDB();

// Проверка авторизации
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

$userId = $_SESSION['user']['id'];

// Получение имени пользователя
$stmt = $connect->prepare("SELECT name, surname FROM users WHERE id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$userData = $result->fetch_assoc();
$userName = $userData ? $userData['name'] . ' ' . $userData['surname'] : 'Пользователь';

// Обработка формы
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $date = mysqli_real_escape_string($connect, $_POST['transport_date']);
    $weight = mysqli_real_escape_string($connect, $_POST['weight']);
    $dimensions = mysqli_real_escape_string($connect, $_POST['dimensions']);
    $from = mysqli_real_escape_string($connect, $_POST['address_from']);
    $to = mysqli_real_escape_string($connect, $_POST['address_to']);
    $type = mysqli_real_escape_string($connect, $_POST['cargo_type']);

    $sql = "INSERT INTO applications 
            (user_id, transport_date, weight, dimensions, address_from, address_to, cargo_type, status) 
            VALUES 
            ('$userId', '$date', '$weight', '$dimensions', '$from', '$to', '$type', 'Новая')";

    if (mysqli_query($connect, $sql)) {
        echo "<script>alert('Заявка успешно отправлена!');</script>";
    } else {
        echo "<script>alert('Ошибка: " . mysqli_error($connect) . "');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Создать заявку</title>
    <link rel="stylesheet" href="assets/style2.css">
</head>
<body>
    <div class="container" style="height: auto;">
        <!-- Левое меню -->
        <aside class="sidebar">
            <div class="logo">
                <img src="assets/img/logo.png" alt="Логотип">
                <h1>Мой Не Сам</h1>
            </div>
            <nav>
                <div class="menu-buttons">
                    <a href="profile.php" class="button">История заявок</a>
                    <a href="#" class="button active">Создать заявку</a>
                </div>
            </nav>
            <a href="src/logout.php" class="logout">&larr; Выйти</a>
        </aside>

        <!-- Основной контент -->
        <div class="main-content">
    <div class="main-header">
        <h2>Создать заявку</h2>
    </div>

    <form action="" method="POST" class="request-form">
        <div class="form-group">
            <label for="transport_date">Дата и время перевозки <span class="required">*</span></label>
            <input type="datetime-local" id="transport_date" name="transport_date" required>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label for="weight">Вес груза (кг)</label>
                <input type="text" id="weight" name="weight" placeholder="Примерно в кг">
            </div>
            <div class="form-group">
                <label for="dimensions">Габариты груза</label>
                <input type="text" id="dimensions" name="dimensions" placeholder="Например: 120x80x60 см">
            </div>
        </div>

        <div class="form-group">
            <label for="address_from">Адрес отправления <span class="required">*</span></label>
            <input type="text" id="address_from" name="address_from" required>
        </div>

        <div class="form-group">
            <label for="address_to">Адрес доставки <span class="required">*</span></label>
            <input type="text" id="address_to" name="address_to" required>
        </div>

        <div class="form-group">
            <label for="cargo_type">Тип груза <span class="required">*</span></label>
            <select id="cargo_type" name="cargo_type" required>
                <option value="" disabled selected>Выберите тип</option>
                <option value="Техника">Техника</option>
                <option value="Продукты">Продукты</option>
                <option value="Стройматериалы">Стройматериалы</option>
                <option value="Другое">Другое</option>
            </select>
        </div>

        <button type="submit" class="submit-button">Отправить заявку</button>
    </form>
</div>

    </div>
    <script src="assets/script.js"></script>
</body>
</html>
