<?php
session_start();
require_once __DIR__ . '/helpers.php';

$login = trim($_POST['login']);
$password = trim($_POST['password']);

$connect = getDB();

$stmt = $connect->prepare("SELECT * FROM users WHERE login = ? AND password = ?");
$stmt->bind_param("ss", $login, $password);
$stmt->execute();
$result = $stmt->get_result();

if ($user = $result->fetch_assoc()) {
    $_SESSION['user']['id'] = $user['id'];
    header("Location: http://localhost/demo1/profile.php");
    exit;
} else {
    header("Location: http://localhost/demo1/login.html?error=1");
    exit;
}
