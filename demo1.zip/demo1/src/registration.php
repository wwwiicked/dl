<?php
require_once __DIR__ . '/helpers.php';

// Получение данных из формы
$login = trim($_POST['login']);
$password = trim($_POST['password']);
$surname = trim($_POST['surname']);
$name = trim($_POST['name']);
$patronymic = trim($_POST['patronymic']);
$phone = trim($_POST['phone']);
$email = trim($_POST['email']);

// Подключение к базе
$connect = getDB();

// Проверка на уникальность логина
$check = $connect->prepare("SELECT id FROM users WHERE login = ?");
$check->bind_param("s", $login);
$check->execute();
$result = $check->get_result();

if ($result->num_rows > 0) {
    echo "Такой логин уже зарегистрирован.";
    exit;
}

// Запись без шифрования пароля
$stmt = $connect->prepare("
  INSERT INTO users (login, password, surname, name, patronymic, phone, email)
  VALUES (?, ?, ?, ?, ?, ?, ?)
");
$stmt->bind_param("sssssss", $login, $password, $surname, $name, $patronymic, $phone, $email);

if ($stmt->execute()) {
    header("Location: http://localhost/demo1/login.html");
    exit;
} else {
    echo "Ошибка регистрации.";
}
