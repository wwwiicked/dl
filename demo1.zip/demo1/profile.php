<?php
session_start();
require_once __DIR__ . '/src/helpers.php';

if (!isset($_SESSION['user']['id'])) {
    header("Location: http://localhost/practica/login.html");
    exit;
}

$connect = getDB();
$userId = $_SESSION['user']['id'];

// Получение имени пользователя
$userQuery = $connect->prepare("SELECT name, surname FROM users WHERE id = ?");
$userQuery->bind_param("i", $userId);
$userQuery->execute();
$userResult = $userQuery->get_result();

$userName = "Неизвестный пользователь";
if ($userResult && $userResult->num_rows > 0) {
    $userData = $userResult->fetch_assoc();
    $userName = $userData['name'] . ' ' . $userData['surname'];
}

// Получение заявок
$requestQuery = $connect->prepare("
    SELECT id, transport_date, weight, dimensions, address_from, address_to, cargo_type, status, created_at
    FROM applications
    WHERE user_id = ?
    ORDER BY created_at DESC
");
$requestQuery->bind_param("i", $userId);
$requestQuery->execute();
$requestResult = $requestQuery->get_result();

$requests = [];
if ($requestResult && $requestResult->num_rows > 0) {
    while ($row = $requestResult->fetch_assoc()) {
        $requests[] = $row;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Получаем данные из формы
    $applicationId = isset($_POST['application_id']) ? intval($_POST['application_id']) : 0;
    $reviewText = isset($_POST['review']) ? trim($_POST['review']) : '';

    if ($applicationId > 0 && !empty($reviewText)) {
        // Проверяем, что заявка принадлежит текущему пользователю
        $stmtCheck = $connect->prepare("SELECT id FROM applications WHERE id = ? AND user_id = ?");
        $stmtCheck->bind_param("ii", $applicationId, $userId);
        $stmtCheck->execute();
        $resultCheck = $stmtCheck->get_result();

        if ($resultCheck && $resultCheck->num_rows > 0) {
            // Вставляем отзыв
            $stmtInsert = $connect->prepare("INSERT INTO reviews (application_id, user_id, content, created_at) VALUES (?, ?, ?, NOW())");
            $stmtInsert->bind_param("iis", $applicationId, $userId, $reviewText);


            if ($stmtInsert->execute()) {
                $_SESSION['message'] = "Отзыв успешно добавлен.";
            } else {
                $_SESSION['message'] = "Ошибка при добавлении отзыва.";
            }
            $stmtInsert->close();
        } else {
            $_SESSION['message'] = "Невозможно оставить отзыв: заявка не найдена или не принадлежит вам.";
        }
        $stmtCheck->close();
    } else {
        $_SESSION['message'] = "Пожалуйста, заполните отзыв.";
    }
} else {
    $_SESSION['message'] = "Некорректный запрос.";
}


?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>История заявок</title>
    <link rel="stylesheet" href="assets/style2.css">
</head>
<body>
<div class="container">
    <!-- Левое меню -->
    <aside class="sidebar">
        <div class="logo">
            <img src="assets/img/logo.png" alt="Логотип">
            <h1>Грузовозофф</h1>
        </div>
        <nav>
            <div class="menu-buttons">
                <a href="#" class="button active">История заявок</a>
                <a href="create_app.php" class="button">Создать заявку</a>
            </div>
        </nav>
        <a href="src/logout.php" class="logout">&larr; Выйти</a>
    </aside>

    <!-- Основной контент -->
    <main class="main-content">
        <header class="main-header">
            <h2>История заявок</h2>
            <div class="user">
                <span><?= htmlspecialchars($userName) ?></span>
                <div class="user-avatar"></div>
            </div>
        </header>
        <section class="request-history">
            <?php if (empty($requests)): ?>
                <p class="no-requests">Вы ещё не оставляли заявок.</p>
            <?php else: ?>
                <?php foreach ($requests as $request): ?>
                    <div class="request-row">
                        <div><strong>Дата перевозки:</strong> <?= htmlspecialchars($request['transport_date']) ?></div>
                        <div><strong>Вес:</strong> <?= htmlspecialchars($request['weight']) ?> кг</div>
                        <div><strong>Габариты:</strong> <?= htmlspecialchars($request['dimensions']) ?></div>
                        <div><strong>Откуда:</strong> <?= htmlspecialchars($request['address_from']) ?></div>
                        <div><strong>Куда:</strong> <?= htmlspecialchars($request['address_to']) ?></div>
                        <div><strong>Тип груза:</strong> <?= htmlspecialchars($request['cargo_type']) ?></div>
                        <div><strong>Статус:</strong> <?= htmlspecialchars($request['status']) ?></div>
                        <div><strong>Создана:</strong> <?= htmlspecialchars($request['created_at']) ?></div>
                        <form action="" method="POST" class="review-form">
                            <input type="hidden" name="application_id" value="<?= $request['id'] ?>">
                            <textarea name="review" placeholder="Оставьте отзыв..." required></textarea>
                            <button type="submit">Оставить отзыв</button>
                        </form>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </section>
    </main>
</div>
</body>
</html>
