document.addEventListener("DOMContentLoaded", function () {
    const phoneInput = document.getElementById('phone');

    phoneInput.addEventListener('input', formatPhone);

    function formatPhone(e) {
      let value = phoneInput.value.replace(/\D/g, ""); // Удаляем все нецифры

      if (value.startsWith("8")) value = "7" + value.slice(1); // Заменяем 8 на 7
      if (!value.startsWith("7")) value = "7" + value;         // Принудительно добавляем 7

      let formatted = "+7";

      if (value.length > 1) formatted += "(" + value.substring(1, 4);
      if (value.length >= 4) formatted += ")";
      if (value.length >= 5) formatted += "-" + value.substring(4, 7);
      if (value.length >= 7) formatted += "-" + value.substring(7, 9);
      if (value.length >= 9) formatted += "-" + value.substring(9, 11);

      phoneInput.value = formatted;
    }
  });

phoneInput.addEventListener('keydown', function (e) {
  const allowedKeys = ["Backspace", "Delete", "ArrowLeft", "ArrowRight", "Tab"];
  if (allowedKeys.includes(e.key)) return;
  if (!/[0-9]/.test(e.key)) e.preventDefault();
});


function validateForm() {
    const login = document.getElementById('login').value.trim();
    const password = document.getElementById('password').value;
    const surname = document.getElementById('surname').value.trim();
    const name = document.getElementById('name').value.trim();
    const patronymic = document.getElementById('patronymic').value.trim();
    const phone = document.getElementById('phone').value.trim();
    const email = document.getElementById('email').value.trim();

    const loginRegex = /^[А-Яа-яЁё]{6,}$/;
    const fioRegex = /^[А-Яа-яЁё\-]+$/;
    const phoneRegex = /^\+7\(\d{3}\)-\d{3}-\d{2}-\d{2}$/;
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    let errors = [];

    if (!loginRegex.test(login)) errors.push("Логин должен быть на кириллице, минимум 6 символов.");
    if (password.length < 6) errors.push("Пароль должен быть не менее 6 символов.");
    if (!fioRegex.test(surname)) errors.push("Фамилия должна содержать только кириллицу.");
    if (!fioRegex.test(name)) errors.push("Имя должно содержать только кириллицу.");
    if (!fioRegex.test(patronymic)) errors.push("Отчество должно содержать только кириллицу.");
    if (!phoneRegex.test(phone)) errors.push("Неверный формат телефона.");
    if (!emailRegex.test(email)) errors.push("Неверный формат email.");

    const errorBlock = document.getElementById("errors");
    errorBlock.innerHTML = '';
    if (errors.length > 0) {
      errors.forEach(e => {
        const p = document.createElement("p");
        p.textContent = e;
        errorBlock.appendChild(p);
      });
      return false;
    }
    return true;
  }