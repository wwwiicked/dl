<?php
session_start();
require_once __DIR__ . '/src/helpers.php';

if (!isset($_SESSION['user']['id'])) {
    header("Location: login.php");
    exit;
}

$connect = getDB();
$userId = $_SESSION['user']['id'];

// Получаем имя пользователя
$stmtUser = $connect->prepare("SELECT name, surname FROM users WHERE id = ?");
$stmtUser->bind_param("i", $userId);
$stmtUser->execute();
$resUser = $stmtUser->get_result();
$userName = "Пользователь";
if ($resUser && $resUser->num_rows > 0) {
    $user = $resUser->fetch_assoc();
    $userName = $user['name'] . ' ' . $user['surname'];
}
$stmtUser->close();

// Обработка отправки отзыва
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $reservationId = isset($_POST['reservation_id']) ? intval($_POST['reservation_id']) : 0;
    $reviewText = isset($_POST['review']) ? trim($_POST['review']) : '';

    if ($reservationId > 0 && !empty($reviewText)) {
        // Проверяем бронирование пользователя с подтверждённым статусом
        $stmtCheck = $connect->prepare("SELECT id FROM reservations WHERE id = ? AND user_id = ? AND status = 'Посещение состоялось' AND reservation_date < NOW()");
        $stmtCheck->bind_param("ii", $reservationId, $userId);
        $stmtCheck->execute();
        $resCheck = $stmtCheck->get_result();

        if ($resCheck && $resCheck->num_rows > 0) {
            // Проверяем, что отзыв ещё не оставлен
            $stmtExist = $connect->prepare("SELECT id FROM reviews WHERE reservation_id = ? AND user_id = ?");
            $stmtExist->bind_param("ii", $reservationId, $userId);
            $stmtExist->execute();
            $resExist = $stmtExist->get_result();

            if ($resExist && $resExist->num_rows == 0) {
                // Вставляем отзыв
                $stmtInsert = $connect->prepare("INSERT INTO reviews (reservation_id, user_id, content, created_at) VALUES (?, ?, ?, NOW())");
                $stmtInsert->bind_param("iis", $reservationId, $userId, $reviewText);
                if ($stmtInsert->execute()) {
                    $_SESSION['message'] = "Отзыв успешно добавлен.";
                } else {
                    $_SESSION['message'] = "Ошибка при добавлении отзыва.";
                }
                $stmtInsert->close();
            } else {
                $_SESSION['message'] = "Вы уже оставили отзыв для этого бронирования.";
            }
            $stmtExist->close();
        } else {
            $_SESSION['message'] = "Невозможно оставить отзыв: бронирование не найдено или не подтверждено.";
        }
        $stmtCheck->close();
    } else {
        $_SESSION['message'] = "Пожалуйста, заполните отзыв.";
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// Получаем бронирования пользователя
$stmtReservations = $connect->prepare("
    SELECT id, reservation_date, guests, contact_phone, status
    FROM reservations
    WHERE user_id = ?
    ORDER BY reservation_date DESC
");
$stmtReservations->bind_param("i", $userId);
$stmtReservations->execute();
$resReservations = $stmtReservations->get_result();

$reservations = [];
if ($resReservations && $resReservations->num_rows > 0) {
    while ($row = $resReservations->fetch_assoc()) {
        $reservations[] = $row;
    }
}
$stmtReservations->close();

// Получаем отзывы пользователя по бронированиям
$reviews = [];
if (!empty($reservations)) {
    $reservationIds = array_column($reservations, 'id');
    $placeholders = implode(',', array_fill(0, count($reservationIds), '?'));
    $types = str_repeat('i', count($reservationIds));

    $sqlReviews = "SELECT reservation_id, content FROM reviews WHERE user_id = ? AND reservation_id IN ($placeholders)";
    $stmtReviews = $connect->prepare($sqlReviews);

    $params = array_merge([$userId], $reservationIds);
    $refs = [];
    foreach ($params as $k => $v) {
        $refs[$k] = &$params[$k];
    }

    call_user_func_array([$stmtReviews, 'bind_param'], array_merge(['i' . $types], $refs));
    $stmtReviews->execute();
    $resReviews = $stmtReviews->get_result();

    while ($rev = $resReviews->fetch_assoc()) {
        $reviews[$rev['reservation_id']] = $rev['content'];
    }
    $stmtReviews->close();
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <title>Мои бронирования - Я буду кушац</title>
  <link rel="stylesheet" href="assets/style2.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
  <style>
    /* Можно добавить специфичные стили для страницы бронирований, если нужно */
    .booking {
      border: 1px solid #ddd;
      padding: 15px;
      margin-bottom: 15px;
      background: #fff;
      border-radius: 15px;
    }
    .booking-status {
      font-weight: bold;
    }
    .status-На_рассмотрении { color: gray; }
    .status-Подтверждена { color: green; }
    .status-Отклонена, .status-Отменена { color: red; }
    .review-box {
      background: #f0f0f0;
      padding: 10px;
      margin-top: 10px;
      white-space: pre-wrap;
      border-radius: 4px;
    }
    textarea {
      width: 100%;
      height: 80px;
      padding: 8px;
      border: 1px solid #ccc;
      border-radius: 4px;
      font-family: Arial, sans-serif;
      font-size: 14px;
      resize: vertical;
    }
    button {
      margin-top: 8px;
      padding: 8px 16px;
      background-color: #5cb85c;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 14px;
    }
    button:hover {
      background-color: #4cae4c;
    }
    .message {
      background: #dff0d8;
      padding: 10px;
      margin-bottom: 20px;
      border: 1px solid #d6e9c6;
      color: #3c763d;
      border-radius: 4px;
    }
    .no-bookings {
      font-style: italic;
      color: #666;
    }
  </style>
</head>
<body>
<div class="container">
  <aside class="sidebar">
    <div class="logo">
      <img src="assets/img/logo.png" alt="Логотип">
      <h1>Я буду кушац</h1>
    </div>
    <nav>
      <div class="menu-buttons">
        <a href="profile.php" class="button active">Мои брони</a>
        <a href="create_app.php" class="button">Забронировать</a>
      </div>
    </nav>
    <a href="src/logout.php" class="logout">&larr; Выйти</a>
  </aside>

  <div class="main-content">
    <header class="main-header">
        <h2>История заявок</h2>
        <div class="user">
            <span><?= htmlspecialchars($userName) ?></span>
            <div class="user-avatar"></div>
        </div>
    </header>

    <?php if (!empty($_SESSION['message'])): ?>
      <div class="message"><?= htmlspecialchars($_SESSION['message']) ?></div>
      <?php unset($_SESSION['message']); ?>
    <?php endif; ?>

    <?php if (empty($reservations)): ?>
      <p class="no-bookings">У вас пока нет бронирований.</p>
    <?php else: ?>
      <?php foreach ($reservations as $resv): ?>
        <div class="booking">
          <div><strong>Дата и время:</strong> <?= htmlspecialchars(date('d.m.Y H:i', strtotime($resv['reservation_date']))) ?></div>
          <div><strong>Гостей:</strong> <?= htmlspecialchars($resv['guests']) ?></div>
          <div><strong>Телефон:</strong> <?= htmlspecialchars($resv['contact_phone']) ?></div>
          <div>
            <strong>Статус:</strong>
            <span class="booking-status status-<?= str_replace(' ', '_', $resv['status']) ?>">
              <?= htmlspecialchars($resv['status']) ?>
            </span>
          </div>

          <?php if (isset($reviews[$resv['id']])): ?>
              <div class="review-box">
                <strong>Ваш отзыв:</strong><br>
                <?= nl2br(htmlspecialchars($reviews[$resv['id']])) ?>
              </div>
          <?php elseif ($resv['status'] === 'Посещение состоялось'):?>
            <!-- elseif ($resv['status'] === 'Посещение состоялось' && strtotime($resv['reservation_date']) < time() - 3600): -->
              <form method="POST" action="">
                  <input type="hidden" name="reservation_id" value="<?= $resv['id'] ?>">
                  <textarea name="review" placeholder="Оставьте отзыв о посещении..." required></textarea>
                  <button type="submit">Отправить отзыв</button>
              </form>
          <?php else: ?>
              <p>Отзывы доступны только после посещения ресторана.</p>
          <?php endif; ?>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>
</div>
</body>
</html>
