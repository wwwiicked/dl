<?php
session_start();
require_once __DIR__ . '/src/helpers.php';

// Простейшая авторизация админа (если ещё не залогинен)
if (!isset($_SESSION['admin_logged_in'])) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $login = $_POST['login'] ?? '';
        $password = $_POST['password'] ?? '';
        if ($login === 'admin' && $password === 'restaurant') {
            $_SESSION['admin_logged_in'] = true;
            header('Location: admin.php');
            exit;
        } else {
            $error = "Неверный логин или пароль";
        }
    }
} else {
    $connect = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_status') {
    $res_id = intval($_POST['res_id']);
    $status = $_POST['status'] ?? '';
    $allowed = ['Новое', 'Посещение состоялось', 'Отменено'];

    if ($res_id > 0 && in_array($status, $allowed)) {
        $stmtCheck = $connect->prepare("SELECT id FROM reservations WHERE id = ?");
        $stmtCheck->bind_param("i", $res_id);
        $stmtCheck->execute();
        $stmtCheck->store_result();

        if ($stmtCheck->num_rows === 0) {
            $_SESSION['message'] = "Бронирование с таким ID не найдено";
            $stmtCheck->close();
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;
        }
        $stmtCheck->close();

        $stmt = $connect->prepare("UPDATE reservations SET status = ? WHERE id = ?");
        $stmt->bind_param("si", $status, $res_id);
        $success = $stmt->execute();

        if (!$success) {
            $_SESSION['message'] = "Ошибка обновления статуса: " . $stmt->error;
        } else {
            $_SESSION['message'] = "Статус бронирования обновлён";
        }
        $stmt->close();

    } else {
        $_SESSION['message'] = "Неверные данные для обновления статуса";
    }

    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'update_status') {
        // ... существующий код обновления статуса ...
    } elseif ($_POST['action'] === 'delete') {
        $res_id = intval($_POST['res_id']);

        if ($res_id > 0) {
            $stmtDelete = $connect->prepare("DELETE FROM reservations WHERE id = ?");
            $stmtDelete->bind_param("i", $res_id);
            $success = $stmtDelete->execute();

            if ($success) {
                $_SESSION['message'] = "Бронирование удалено успешно.";
            } else {
                $_SESSION['message'] = "Ошибка при удалении: " . $stmtDelete->error;
            }

            $stmtDelete->close();
        } else {
            $_SESSION['message'] = "Неверный ID для удаления.";
        }

        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    }
}


    // Параметры фильтрации и пагинации
    $filterStatus = $_GET['status'] ?? 'all';
    $page = max(1, intval($_GET['page'] ?? 1));
    $perPage = 10;
    $offset = ($page - 1) * $perPage;

    // Формируем условие фильтра
    $whereSQL = '';
    $params = [];
    $types = '';
    if ($filterStatus !== 'all') {
        $whereSQL = "WHERE status = ?";
        $params[] = $filterStatus;
        $types .= 's';
    }

    // Получаем общее количество для пагинации
    $countSQL = "SELECT COUNT(*) FROM reservations $whereSQL";
    $stmtCount = $connect->prepare($countSQL);
    if ($whereSQL) {
        $stmtCount->bind_param($types, ...$params);
    }
    $stmtCount->execute();
    $stmtCount->bind_result($totalCount);
    $stmtCount->fetch();
    $stmtCount->close();

    $totalPages = ceil($totalCount / $perPage);

    // Получаем бронирования с юзерами
    $sql = "SELECT r.id, r.reservation_date, r.guests, r.contact_phone, r.status, r.created_at, u.name, u.surname 
            FROM reservations r
            JOIN users u ON r.user_id = u.id
            $whereSQL
            ORDER BY r.created_at DESC
            LIMIT ? OFFSET ?";
    $stmt = $connect->prepare($sql);

    if ($whereSQL) {
        $types .= 'ii';
        $params[] = $perPage;
        $params[] = $offset;
        $stmt->bind_param($types, ...$params);
    } else {
        $stmt->bind_param("ii", $perPage, $offset);
    }

    $stmt->execute();
    $result = $stmt->get_result();
    $reservations = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8" />
    <title>Панель администратора - Бронирования</title>
    <link rel="stylesheet" href="assets/style2.css" />
    <link rel="stylesheet" href="assets/st.css" />
</head>
<body>

<?php if (!isset($_SESSION['admin_logged_in'])): ?>
    <div class="login-form">
        <h2>Вход в панель администратора</h2>
        <?php if (!empty($error)): ?>
            <div class="error"><?=htmlspecialchars($error)?></div>
        <?php endif; ?>
        <form method="POST">
            <label for="login">Логин</label>
            <input type="text" name="login" id="login" required autofocus>

            <label for="password">Пароль</label>
            <input type="password" name="password" id="password" required>

            <button type="submit">Войти</button>
        </form>
    </div>

<?php else: ?>
    <div class="container">
        <aside class="sidebar">
            <div class="logo">
                <h1>Панель администратора</h1>
            </div>
            <nav>
                <a href="src/logout.php" class="logout">&larr; Выйти</a>
            </nav>
        </aside>

        <main class="main-content">
            <h2>Управление бронированиями</h2>

            <?php if (isset($_SESSION['message'])): ?>
                <div class="message"><?=htmlspecialchars($_SESSION['message'])?></div>
                <?php unset($_SESSION['message']); ?>
            <?php endif; ?>

            <form method="GET" class="filter-form">
                <label for="status">Фильтр по статусу:</label>
                <select name="status" id="status" onchange="this.form.submit()">
                    <option value="all" <?= $filterStatus === 'all' ? 'selected' : '' ?>>Все</option>
                    <option value="Новое" <?= $filterStatus === 'Новое' ? 'selected' : '' ?>>Новое</option>
                    <option value="Посещение состоялось" <?= $filterStatus === 'Посещение состоялось' ? 'selected' : '' ?>>Посещение состоялось</option>
                    <option value="Отменено" <?= $filterStatus === 'Отменено' ? 'selected' : '' ?>>Отменено</option>
                </select>
            </form>

            <?php if (empty($reservations)): ?>
                <p>Бронирований не найдено.</p>
            <?php else: ?>
                <table>
                    <thead>
                    <tr>
                        <th>Пользователь</th>
                        <th>Дата и время бронирования</th>
                        <th>Гостей</th>
                        <th>Телефон</th>
                        <th>Статус</th>
                        <th>Действия</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($reservations as $resv): ?>
                        <tr>
                            <td><?=htmlspecialchars($resv['name'] . ' ' . $resv['surname'])?></td>
                            <td><?=htmlspecialchars(date('d.m.Y H:i', strtotime($resv['reservation_date'])))?></td>
                            <td><?=htmlspecialchars($resv['guests'])?></td>
                            <td><?=htmlspecialchars($resv['contact_phone'])?></td>
                            <td>
                                <form method="POST" style="margin:0;">
                                    <input type="hidden" name="res_id" value="<?= $resv['id'] ?>">
                                    <input type="hidden" name="action" value="update_status">
                                    <select name="status" onchange="this.form.submit()">
                                        <option value="Новое" <?= $resv['status'] === 'Новое' ? 'selected' : '' ?>>Новое</option>
                                        <option value="Посещение состоялось" <?= $resv['status'] === 'Посещение состоялось' ? 'selected' : '' ?>>Посещение состоялось</option>
                                        <option value="Отменено" <?= $resv['status'] === 'Отменено' ? 'selected' : '' ?>>Отменено</option>
                                    </select>
                                </form>
                            </td>
                            <td>
                                <form method="POST" onsubmit="return confirm('Вы уверены, что хотите удалить бронирование?');" style="margin:0;">
                                    <input type="hidden" name="res_id" value="<?= $resv['id'] ?>">
                                    <input type="hidden" name="action" value="delete">
                                    <button type="submit" style="color: red; background: none; border: none; cursor: pointer;">Удалить</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>

                <div class="pagination">
                    <?php for ($p = 1; $p <= $totalPages; $p++): ?>
                        <a href="?status=<?= urlencode($filterStatus) ?>&page=<?= $p ?>"
                           class="<?= $p === $page ? 'active' : '' ?>"><?= $p ?></a>
                    <?php endfor; ?>
                </div>
            <?php endif; ?>
        </main>
    </div>
<?php endif; ?>

</body>
</html>