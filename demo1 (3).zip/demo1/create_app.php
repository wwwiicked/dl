<?php
session_start();
require_once __DIR__ . '/src/helpers.php'; // подключение к базе

$connect = getDB();

// Проверка авторизации
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

$userId = $_SESSION['user']['id'];

// Получение имени пользователя
$stmt = $connect->prepare("SELECT name, surname FROM users WHERE id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$userData = $result->fetch_assoc();
$userName = $userData ? $userData['name'] . ' ' . $userData['surname'] : 'Пользователь';

// Обработка формы бронирования
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $date = str_replace('T', ' ', $_POST['reservation_date']) . ':00';
    $guests = (int) $_POST['guests'];
    $phone = $_POST['contact_phone'];

    if ($guests >= 1 && $guests <= 10) {
        $sql = "INSERT INTO reservations (user_id, reservation_date, guests, contact_phone, status)
                VALUES (?, ?, ?, ?, 'Новое')";
        $stmt = $connect->prepare($sql);
        $stmt->bind_param("isis", $userId, $date, $guests, $phone);

        if ($stmt->execute()) {
            echo "<script>alert('Бронирование успешно отправлено на рассмотрение!');</script>";
        } else {
            echo "<script>alert('Ошибка при бронировании.');</script>";
        }
    } else {
        echo "<script>alert('Количество гостей должно быть от 1 до 10');</script>";
    }
}

?>

<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <title>Бронирование столика - Я буду кушац</title>
  <link rel="stylesheet" href="assets/style2.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
</head>
<body>
<div class="container">
  <aside class="sidebar">
    <div class="logo">
      <img src="assets/img/logo.png" alt="Логотип">
      <h1>Я буду кушац</h1>
    </div>
    <nav>
      <div class="menu-buttons">
        <a href="profile.php" class="button">Мои брони</a>
        <a href="#" class="button active">Забронировать</a>
      </div>
    </nav>
    <a href="src/logout.php" class="logout">&larr; Выйти</a>
  </aside>

  <div class="main-content">
    <div class="main-header">
      <h2>Бронирование столика</h2>
    </div>

    <form method="POST" action="" class="request-form">
      <div class="form-group">
        <label for="reservation_date">Дата и время <span class="required">*</span></label>
        <input type="datetime-local" id="reservation_date" name="reservation_date" required>
      </div>

      <div class="form-group">
        <label for="guests">Количество гостей <span class="required">*</span></label>
        <select id="guests" name="guests" required>
          <option value="" disabled selected>Выберите количество</option>
          <?php for ($i = 1; $i <= 10; $i++): ?>
              <option value="<?= $i ?>"><?= $i ?></option>
          <?php endfor; ?>
        </select>
      </div>

      <div class="form-group">
        <label for="contact_phone">Контактный номер телефона <span class="required">*</span></label>
        <input type="tel" id="contact_phone" name="contact_phone" placeholder="+7(___)-___-__-__" required>
      </div>

      <button type="submit" class="submit-button">Забронировать</button>
    </form>
  </div>
</div>

<script>
  $(document).ready(function(){
    $('#contact_phone').mask('+7(000)-000-00-00');
  });
</script>
</body>
</html>

