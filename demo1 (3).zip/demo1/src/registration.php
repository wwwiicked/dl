<?php
require_once __DIR__ . '/helpers.php';

function isValidLogin($login) {
    return preg_match('/^[А-Яа-яЁё]{6,}$/u', $login);
}

function isValidPhone($phone) {
    return preg_match('/^\+7\(\d{3}\)-\d{3}-\d{2}-\d{2}$/', $phone);
}

function isValidEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

$login = trim($_POST['login']);
$password = trim($_POST['password']);
$surname = trim($_POST['surname']);
$name = trim($_POST['name']);
$patronymic = trim($_POST['patronymic']);
$phone = trim($_POST['phone']);
$email = trim($_POST['email']);

// Проверка всех данных
if (
    !isValidLogin($login) || strlen($password) < 6 ||
    empty($surname) || empty($name) || empty($patronymic) ||
    !isValidPhone($phone) || !isValidEmail($email)
) {
    echo "Неверно заполнены поля.";
    exit;
}

// Удаляем хеширование:
$connect = getDB();

// Проверка логина:
$check = $connect->prepare("SELECT id FROM users WHERE login = ?");
$check->bind_param("s", $login);
$check->execute();
$result = $check->get_result();

if ($result->num_rows > 0) {
    echo "Такой логин уже зарегистрирован.";
    exit;
}

// Пароль сохраняется в открытом виде (НЕБЕЗОПАСНО!)
$stmt = $connect->prepare("
  INSERT INTO users (login, password, surname, name, patronymic, phone, email)
  VALUES (?, ?, ?, ?, ?, ?, ?)
");
$stmt->bind_param("sssssss", $login, $password, $surname, $name, $patronymic, $phone, $email);

if ($stmt->execute()) {
    header("Location: http://localhost/demo1/login.html");
    exit;
} else {
    echo "Ошибка регистрации.";
}
